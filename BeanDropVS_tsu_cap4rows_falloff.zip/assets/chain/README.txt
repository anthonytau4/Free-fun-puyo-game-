Put your chain voice files in this folder.

Required filenames:
- chain_1.mp3
- chain_2.mp3
- chain_3.mp3
- chain_4.mp3
- chain_5.mp3
- chain_6.mp3
- chain_6plus.mp3   (used for chain 7+; repeats each wave)

The game will set the between-chain wait time to the clip duration.

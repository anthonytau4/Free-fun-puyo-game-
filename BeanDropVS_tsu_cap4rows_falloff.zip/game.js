/* Bean Drop VS — Tsu-inspired rules (not a ROM clone)
   - Works offline (double click index.html)
   - Uses your provided assets in /assets
*/
'use strict';

const CONFIG = {
  COLS: 6,
  VISIBLE_ROWS: 12,
  HIDDEN_ROWS: 2,
  ROWS() { return this.VISIBLE_ROWS + this.HIDDEN_ROWS; },

  COLORS: ['red','green','blue','yellow','purple'],
  CELL_EMPTY: 0,
  CELL_GARBAGE: 6,

  // Timings (frames at 60fps) tuned from documented Tsu frame data:
  // - Input repeat: 8 frame delay, 2 frame repeat (gameplay)  (Puyo Nexus) 
  // - Grace period before control lockout: 32 frames (Tsu) (Puyo Nexus)
  // - Rotation animation: 8 frames; bounce animation: 16 frames (Puyo Nexus)
  FPS: 60,
  INPUT_DAS_FRAMES: 8,
  INPUT_ARR_FRAMES: 2,

  DEFAULT_LOCK_DELAY_FRAMES: 30, // Tsu-like global grace
  ROT_ANIM_FRAMES: 8,
  BOUNCE_ANIM_FRAMES: 16,

  // Feel / polish
  SPAWN_DELAY_MS: 90,
  CHAIN_POP_PAUSE_MS: 180,
  CHAIN_FALL_PAUSE_MS: 120,
  // Requested: dramatic pause between chain links.
  CHAIN_STEP_DELAY_MS: 1000,
  GARBAGE_DROP_PAUSE_MS: 160,

  // Speed presets
  GRAVITY_CELLS_PER_SEC: {
    slow: 2.2,
    normal: 3.2,
    fast: 4.4
  },

  // CPU falls a bit slower (requested)
  CPU_FALL_MULT: 0.5,
  SOFT_DROP_MULT: 8.0,

  // Garbage
  TARGET_POINTS: 70,             // default score per garbage puyo
  GARBAGE_CAP_PER_DROP: 30,       // 5 rows max per drop (common modern cap)
  GARBAGE_ROWS_PER_DROP: 5,       // 5 rows = 30 puyo
  ALL_CLEAR_BONUS: 30,            // zenkeshi bonus in Tsu rule

  // AI
  AI_BEAM: 18,                    // number of candidate placements kept for lookahead
  AI_LOOKAHEAD: 2,                // 1 = current only, 2 = current+next
};
CONFIG.SPAWN_X = Math.floor((CONFIG.COLS - 1) / 2);

const SPRITES = {"red": {"x": 1061, "y": 156, "w": 382, "h": 287}, "purple": {"x": 832, "y": 525, "w": 385, "h": 282}, "green": {"x": 203, "y": 158, "w": 380, "h": 285}, "blue": {"x": 1512, "y": 158, "w": 378, "h": 284}, "yellow": {"x": 630, "y": 157, "w": 377, "h": 284}};

const ASSETS = {
  sheet: 'assets/puyo_sheet.png',
  garbage: 'assets/puyos/garbage.png',
  music: 'assets/music/theme.mp3',
  // Premade chain step animations (from your asset ZIP)
  chainAnim: [
    'assets/chain_anim/chain_anim_1.png',
    'assets/chain_anim/chain_anim_2.png',
    'assets/chain_anim/chain_anim_3.png',
    'assets/chain_anim/chain_anim_4.png',
    'assets/chain_anim/chain_anim_5.png',
    'assets/chain_anim/chain_anim_6.png',
    'assets/chain_anim/chain_anim_6plus.png',
  ],
  // Chain sfx: chain_1..chain_6 and chain_6plus (7+)
  chainSfx: [
    'assets/chain/chain_1.mp3',
    'assets/chain/chain_2.mp3',
    'assets/chain/chain_3.mp3',
    'assets/chain/chain_4.mp3',
    'assets/chain/chain_5.mp3',
    'assets/chain/chain_6.mp3',
    'assets/chain/chain_6plus.mp3',
  ],
  // Enemy/AI chain sfx (so it doesn't sound identical)
  aiChainSfx: [
    'assets/chain/enemy_chain_1.mp3',
    'assets/chain/enemy_chain_2.mp3',
    'assets/chain/enemy_chain_3.mp3',
    'assets/chain/enemy_chain_4.mp3',
    'assets/chain/enemy_chain_5.mp3',
    'assets/chain/enemy_chain_6.mp3',
    'assets/chain/enemy_chain_6plus.mp3',
  ]
};


// ---------- Utilities ----------
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a,b,t) => a + (b-a)*t;
const now = () => performance.now();

const easeOutCubic = (t) => 1 - Math.pow(1 - clamp(t,0,1), 3);
const easeInOutQuad = (t) => (t<0.5) ? 2*t*t : 1 - Math.pow(-2*t+2,2)/2;

function hash32(a,b,c) {
  // cheap deterministic hash for sparkles
  let x = (a|0) * 374761393 + (b|0) * 668265263 + (c|0) * 2147483647;
  x = (x ^ (x >>> 13)) >>> 0;
  x = Math.imul(x, 1274126177) >>> 0;
  return x >>> 0;
}

function mulberry32(seed) {
  let t = seed >>> 0;
  return function() {
    t += 0x6D2B79F5;
    let x = Math.imul(t ^ (t >>> 15), 1 | t);
    x ^= x + Math.imul(x ^ (x >>> 7), 61 | x);
    return ((x ^ (x >>> 14)) >>> 0) / 4294967296;
  };
}

function deepCloneGrid(grid) {
  return grid.map(row => row.slice());
}

function countHoles(grid, cols, rows) {
  // A "hole" is an empty cell with at least one filled cell above in the same column.
  let holes = 0;
  for (let x=0; x<cols; x++) {
    let seenBlock = false;
    for (let y=0; y<rows; y++) {
      const v = grid[y][x];
      if (v !== 0) seenBlock = true;
      else if (seenBlock) holes++;
    }
  }
  return holes;
}

function maxHeight(grid, cols, rows) {
  // height above the floor (0..rows)
  let mh = 0;
  for (let x=0; x<cols; x++) {
    for (let y=0; y<rows; y++) {
      if (grid[y][x] !== 0) {
        mh = Math.max(mh, rows - y);
        break;
      }
    }
  }
  return mh;
}

// ---------- Audio ----------
class AudioBank {
  constructor() {
    this.musicOn = true;
    this.sfxOn = true;
    this._unlocked = false;
    this.music = new Audio(ASSETS.music);
    this.music.loop = true;
    this.music.volume = 0.45;

    this.sfx = {
      chain: ASSETS.chainSfx.map(p => new Audio(p)),
      chainEnemy: (ASSETS.aiChainSfx || ASSETS.chainSfx).map(p => new Audio(p)),
    };
    for (const a of Object.values(this.sfx)) {
      if (Array.isArray(a)) a.forEach(x => x.volume = 0.65);
      else a.volume = 0.65;
    }
  }

  unlock() {
    if (this._unlocked) return;
    this._unlocked = true;
    this.music.play().then(()=>this.music.pause()).catch(()=>{});
  }

  setMusic(on) {
    this.musicOn = on;
    if (!on) this.music.pause();
    else this.music.play().catch(()=>{});
  }

  setSfx(on) {
    this.sfxOn = on;
  }

  playSfx(name) {
    if (!this.sfxOn) return;
    const a = this.sfx[name];
    if (!a) return;
    try {
      a.currentTime = 0;
      a.play().catch(()=>{});
    } catch(_e) {}
  }

  playChain(chainIndex, isEnemy=false) {
    if (!this.sfxOn) return;
    const idx = chainIndex >= 7 ? 6 : clamp(chainIndex-1, 0, 5);
    const bank = (isEnemy && this.sfx.chainEnemy) ? this.sfx.chainEnemy : this.sfx.chain;
    const a = bank[idx];
    try {
      a.currentTime = 0;
      a.play().catch(()=>{});
    } catch(_e) {}
  }
}

// ---------- Input ----------
class Input {
  constructor(targetEl) {
    this.keys = new Set();
    this.pressed = new Set();
    this.released = new Set();
    this._repeat = new Map(); // key -> {t, phase}

    window.addEventListener('keydown', (e) => {
      const key = e.key.toLowerCase();
      if (['arrowleft','arrowright','arrowdown','arrowup',' ','z','x','p','r','t'].includes(key) || key === ' ') {
        e.preventDefault();
      }
      if (!this.keys.has(key)) {
        this.pressed.add(key);
        this._repeat.set(key, {t:0, phase:0});
      }
      this.keys.add(key);
    }, {passive:false});

    window.addEventListener('keyup', (e) => {
      const key = e.key.toLowerCase();
      this.keys.delete(key);
      this.released.add(key);
      this._repeat.delete(key);
    });

    targetEl.addEventListener('mousedown', () => {
      window.__audio?.unlock?.();
      window.__audio?.setMusic?.(window.__audio.musicOn);
    });
  }

  beginFrame() {
    this.pressed.clear();
    this.released.clear();
  }

  isDown(k) { return this.keys.has(k); }
  wasPressed(k) { return this.pressed.has(k); }

  repeatPressed(k, dtFrames, dasFrames, arrFrames) {
    if (!this.keys.has(k)) return false;
    const st = this._repeat.get(k);
    if (!st) return false;

    st.t += dtFrames;
    if (this.pressed.has(k)) return true;
    if (st.phase === 0) {
      if (st.t >= dasFrames) {
        st.phase = 1;
        st.t = 0;
        return true;
      }
    } else {
      if (st.t >= arrFrames) {
        st.t = 0;
        return true;
      }
    }
    return false;
  }
}

// ---------- Puyo logic ----------
function makeEmptyGrid() {
  const rows = CONFIG.ROWS();
  const g = [];
  for (let y=0; y<rows; y++) {
    const row = new Array(CONFIG.COLS).fill(0);
    g.push(row);
  }
  return g;
}

function randBag(rng, colors) {
  const bag = colors.slice();
  for (let i=bag.length-1; i>0; i--) {
    const j = Math.floor(rng()* (i+1));
    [bag[i], bag[j]] = [bag[j], bag[i]];
  }
  return bag;
}

class Piece {
  constructor(a, b) {
    this.pivot = a;
    this.sat = b;
    this.x = 2;
    this.y = 0;
    this.rot = 0;
    this.lockTimer = 0;
  }

  satOffset() {
    switch (this.rot) {
      case 0: return [0,-1];
      case 1: return [1,0];
      case 2: return [0,1];
      case 3: return [-1,0];
    }
    return [0,-1];
  }

  cells() {
    const [dx,dy] = this.satOffset();
    return [
      {x:this.x, y:this.y, v:this.pivot},
      {x:this.x+dx, y:this.y+dy, v:this.sat},
    ];
  }
}

function inBounds(x,y) {
  return x>=0 && x<CONFIG.COLS && y>=0 && y<CONFIG.ROWS();
}

function canPlace(grid, cells) {
  for (const c of cells) {
    if (!inBounds(c.x, c.y)) return false;
    if (grid[c.y][c.x] !== 0) return false;
  }
  return true;
}

function canMove(piece, grid, dx, dy) {
  const saved = {x:piece.x, y:piece.y};
  piece.x += dx; piece.y += dy;
  const ok = canPlace(grid, piece.cells());
  piece.x = saved.x; piece.y = saved.y;
  return ok;
}

function canRotate(piece, grid, dir) {
  const saved = piece.rot;
  const target = (piece.rot + dir + 4) % 4;
  piece.rot = target;
  if (canPlace(grid, piece.cells())) {
    piece.rot = saved;
    return true;
  }
  for (const k of [-1,1]) {
    const savedX = piece.x;
    piece.x += k;
    const ok = canPlace(grid, piece.cells());
    piece.x = savedX;
    if (ok) {
      piece.rot = saved;
      return true;
    }
  }
  piece.rot = saved;
  return false;
}

function applyRotate(piece, grid, dir) {
  const savedX = piece.x;
  const savedRot = piece.rot;
  const target = (piece.rot + dir + 4) % 4;
  piece.rot = target;
  if (canPlace(grid, piece.cells())) return true;
  for (const k of [-1,1]) {
    piece.x = savedX + k;
    if (canPlace(grid, piece.cells())) return true;
  }
  piece.x = savedX;
  piece.rot = savedRot;
  return false;
}

function hardDropDistance(piece, grid) {
  let d=0;
  while (canMove(piece, grid, 0, 1)) {
    piece.y += 1;
    d += 1;
  }
  piece.y -= d;
  return d;
}

function placePiece(grid, piece) {
  for (const c of piece.cells()) {
    grid[c.y][c.x] = c.v;
  }
}

function applyGravity(grid) {
  const rows = CONFIG.ROWS();
  let moved = false;
  for (let x=0; x<CONFIG.COLS; x++) {
    let write = rows-1;
    for (let y=rows-1; y>=0; y--) {
      const v = grid[y][x];
      if (v !== 0) {
        if (y !== write) {
          grid[write][x] = v;
          grid[y][x] = 0;
          moved = true;
        }
        write--;
      }
    }
  }
  return moved;
}

function findGroupsToClear(grid) {
  const rows = CONFIG.ROWS();
  const visited = Array.from({length: rows}, ()=>Array(CONFIG.COLS).fill(false));
  const groups = [];
  const dirs = [[1,0],[-1,0],[0,1],[0,-1]];

  for (let y=0; y<rows; y++) {
    for (let x=0; x<CONFIG.COLS; x++) {
      const v = grid[y][x];
      if (v === 0 || v === CONFIG.CELL_GARBAGE || visited[y][x]) continue;
      const q = [[x,y]];
      visited[y][x] = true;
      const cells = [];
      while (q.length) {
        const [cx,cy] = q.pop();
        cells.push([cx,cy]);
        for (const [dx,dy] of dirs) {
          const nx=cx+dx, ny=cy+dy;
          if (!inBounds(nx,ny)) continue;
          if (visited[ny][nx]) continue;
          if (grid[ny][nx] === v) {
            visited[ny][nx] = true;
            q.push([nx,ny]);
          }
        }
      }
      if (cells.length >= 4) {
        groups.push({color:v, cells});
      }
    }
  }
  if (!groups.length) return null;

  const clear = new Set();
  const add = (x,y)=>clear.add(y*100+x);
  for (const g of groups) {
    for (const [x,y] of g.cells) add(x,y);
  }
  for (const g of groups) {
    for (const [x,y] of g.cells) {
      for (const [dx,dy] of dirs) {
        const nx=x+dx, ny=y+dy;
        if (!inBounds(nx,ny)) continue;
        if (grid[ny][nx] === CONFIG.CELL_GARBAGE) add(nx,ny);
      }
    }
  }

  const colorsCleared = new Set();
  const groupSizes = [];
  let clearedCount = 0;
  let clearedColored = 0;
  for (const key of clear) {
    const y = Math.floor(key/100);
    const x = key%100;
    const v = grid[y][x];
    clearedCount++;
    if (v !== CONFIG.CELL_GARBAGE) {
      clearedColored++;
      colorsCleared.add(v);
    }
  }
  for (const g of groups) groupSizes.push(g.cells.length);

  return {
    clearKeys: clear,
    clearedCount,
    clearedColored,
    colorsClearedCount: colorsCleared.size,
    groupSizes,
  };
}

// Scoring tables (classic)
const COLOR_BONUS = {1:0,2:3,3:6,4:12,5:24,6:48};
function groupBonusForSize(n) {
  if (n <= 4) return 0;
  if (n === 5) return 2;
  if (n === 6) return 3;
  if (n === 7) return 4;
  if (n === 8) return 5;
  if (n === 9) return 6;
  if (n === 10) return 7;
  return 10;
}
// Attack power table for Tsu (used as chain power CP in classic scoring).
// Values from Puyo Nexus (Tsu rule, classic). CP=0 treated as 1.
const CHAIN_POWER_TSU = [0,8,16,32,64,96,128,160,192,224,256,288,320,352,384,416,448,480,512,544,576,608,640,672];

function computeChainScore(chainIndex, clearedColored, colorsClearedCount, groupSizes) {
  const pc = clearedColored;
  let cp = CHAIN_POWER_TSU[chainIndex-1] ?? 672;
  if (cp === 0) cp = 1;
  const cb = COLOR_BONUS[colorsClearedCount] ?? 48;
  let gb = 0;
  for (const s of groupSizes) gb += groupBonusForSize(s);
  let bonus = cp + cb + gb;
  bonus = clamp(bonus, 1, 999);
  return (10 * pc) * bonus;
}

function nuisanceFromScore(score, carry) {
  const np = (score / CONFIG.TARGET_POINTS) + carry;
  const nc = Math.floor(np + 1e-9);
  const nl = np - nc;
  return {send:nc, carry:nl};
}

function isAllClear(grid) {
  const rows = CONFIG.ROWS();
  for (let y=0; y<rows; y++) {
    for (let x=0; x<CONFIG.COLS; x++) {
      if (grid[y][x] !== 0) return false;
    }
  }
  return true;
}

// ---------- Garbage drop ----------
function dropGarbage(grid, count, rng) {
  // Drops nuisance puyos into the *lowest available* empty cells, capped per batch.
  // IMPORTANT: must never hang if the board is full (can happen near top-out).
  let remaining = Math.max(0, count|0);
  const rows = CONFIG.ROWS();
  let safetyOuter = 0;

  while (remaining > 0 && safetyOuter++ < 200) {
    const batch = Math.min(remaining, CONFIG.GARBAGE_CAP_PER_DROP);
    remaining -= batch;

    let toDrop = batch;
    let safetyInner = 0;

    while (toDrop > 0 && safetyInner++ < 400) {
      const rowCount = Math.min(CONFIG.COLS, toDrop);
      const hole = rowCount === CONFIG.COLS ? Math.floor(rng() * CONFIG.COLS) : -1;

      let placedAny = false;

      for (let x=0; x<CONFIG.COLS; x++) {
        if (hole === x) continue;
        if (toDrop <= 0) break;

        // Find the lowest empty cell in this column (scan from bottom up).
        for (let y=rows-1; y>=0; y--) {
          if (grid[y] && grid[y][x] === 0) {
            grid[y][x] = CONFIG.CELL_GARBAGE;
            toDrop--;
            placedAny = true;
            break;
          }
        }
      }

      // If we couldn't place anything, the field is effectively full.
      // Bail out to avoid infinite loops / freezes; the top-out logic will handle the loss.
      if (!placedAny) return;

      applyGravity(grid);
    }
  }
}

// ---------- Side ----------
class Side {
  constructor(name, isCpu, rng) {
    this.name = name;
    this.isCpu = isCpu;

    // Board position for cosmetics (left/right) — affects chain voice.
    this.boardSide = 'left';
    this.rng = rng;

    this.grid = makeEmptyGrid();
    this.active = null;
    this.next = [];
    this.bag = [];
    this.pendingGarbage = 0;
    this.pendingGarbageNext = 0; // armed but not droppable until after next spawn boundary
    this.attackPending = 0; // outgoing nuisance waiting for offset
    this.isResolving = false;
    this._incomingLocked = 0;
    this.sentCarry = 0;
    this.score = 0;
    this.stateLabel = 'Ready';
    this.allClearArmed = false;

    // Visual effects (chain pops, text, flashes)
    this.fx = [];
    this._flash = null;
  }

  ensureNext() {
    while (this.next.length < 3) {
      if (this.bag.length < 2) this.bag = randBag(this.rng, CONFIG.COLORS);
      const a = this.bag.pop();
      if (this.bag.length < 1) this.bag = randBag(this.rng, CONFIG.COLORS);
      const b = this.bag.pop();
      const ai = 1 + CONFIG.COLORS.indexOf(a);
      const bi = 1 + CONFIG.COLORS.indexOf(b);
      this.next.push([ai, bi]);
    }
  }

  spawn() {
    this.ensureNext();
    const [a,b] = this.next.shift();
    const p = new Piece(a,b);
    p.x = CONFIG.SPAWN_X;
    p.y = 1;
    p.rot = 0;
    this.active = p;
    return canPlace(this.grid, p.cells());
  }

  lockActive() {
    if (!this.active) return;
    placePiece(this.grid, this.active);
    this.active = null;
  }

  visibleTopOut() {
    const x = CONFIG.SPAWN_X;
    return this.grid[0][x] !== 0;
  }
}

// ---------- AI ----------
class AIPlanner {
  constructor() {
    this.plan = null;
    this.state = 'Building';
  }

  compute(side, opponent, difficulty) {
    const depth = 2; // capped to avoid frame stalls (continuous play)
    const deadline = now() + (difficulty>=4 ? 8.0 : 6.0); // ms budget per plan
    const beam = difficulty >= 5 ? 20 : (difficulty >= 3 ? 18 : 14);
    const w = {
      // Strong bias toward building/launching large chains (requested).
      attack: lerp(0.7, 1.4, (difficulty-1)/4),
      chain:  lerp(3.5, 6.0, (difficulty-1)/4),
      score:  lerp(0.0022, 0.0038, (difficulty-1)/4),
      height: lerp(1.2, 1.7, (difficulty-1)/4),
      holes:  lerp(1.8, 2.4, (difficulty-1)/4),
      link:   lerp(1.0, 1.8, (difficulty-1)/4),
      safety: lerp(1.0, 1.8, (difficulty-1)/4),
      garbage: lerp(1.8, 2.6, (difficulty-1)/4),
    };

    const danger = side.pendingGarbage >= 18 || this.spawnColumnHeight(side.grid) >= 11;
    this.state = danger ? 'Counteract' : 'Building';

    side.ensureNext();
    const pieces = [
      [side.active?.pivot ?? side.next[0][0], side.active?.sat ?? side.next[0][1]],
    ];
    if (depth >= 2) pieces.push(side.active ? side.next[0] : side.next[1]);
    if (depth >= 3) pieces.push(side.active ? side.next[1] : side.next[2]);

    const best = this.search(side.grid, pieces, beam, w, side.pendingGarbage, danger, deadline);
    this.plan = best ? best.plan : null;
  }

  search(grid, pieces, beam, w, incoming, danger, deadline) {
    const firstPlacements = this.enumeratePlacements(grid, pieces[0]);

    const scored = [];
    for (const pl of firstPlacements) {
      if (deadline && now() > deadline) break;
      const sim = this.simulate(grid, pl);
      const s = this.evaluate(sim, w, incoming, danger);
      scored.push({s, first:pl, sim});
    }
    scored.sort((a,b)=>b.s-a.s);
    const top = scored.slice(0, beam);

    if (pieces.length === 1) {
      const pick = top[0];
      return pick ? {score:pick.s, plan:this.buildPlan(pick.first)} : null;
    }

let bestOverall = null;
for (const cand of top) {
  if (deadline && now() > deadline) break;
  const g2 = cand.sim.grid;
  const placements2 = this.enumeratePlacements(g2, pieces[1]);

  if (pieces.length === 2) {
    let best2 = -1e18;
    for (const pl2 of placements2) {
      if (deadline && now() > deadline) break;
      const sim2 = this.simulate(g2, pl2);
      const s2 = this.evaluate(sim2, w, incoming, danger);
      const combined = cand.s + 0.72 * s2;
      if (combined > best2) best2 = combined;
    }
    if (!bestOverall || best2 > bestOverall.score) {
      bestOverall = {score:best2, plan:this.buildPlan(cand.first)};
    }
    continue;
  }

  // 3-ply lookahead with pruning (keeps it fast enough in JS).
  const scored2 = [];
  for (const pl2 of placements2) {
      if (deadline && now() > deadline) break;
    const sim2 = this.simulate(g2, pl2);
    const s2 = this.evaluate(sim2, w, incoming, danger);
    const combined2 = cand.s + 0.72 * s2;
    scored2.push({combined2, sim: sim2});
  }
  scored2.sort((a,b)=>b.combined2-a.combined2);
  const top2 = scored2.slice(0, Math.min(10, scored2.length));

  let best3 = -1e18;
  for (const cand2 of top2) {
    if (deadline && now() > deadline) break;
    const g3 = cand2.sim.grid;
    const placements3 = this.enumeratePlacements(g3, pieces[2]);
    for (const pl3 of placements3) {
      if (deadline && now() > deadline) break;
      const sim3 = this.simulate(g3, pl3);
      const s3 = this.evaluate(sim3, w, incoming, danger);
      const combined3 = cand2.combined2 + 0.55 * s3;
      if (combined3 > best3) best3 = combined3;
    }
  }

  if (!bestOverall || best3 > bestOverall.score) {
    bestOverall = {score:best3, plan:this.buildPlan(cand.first)};
  }
}
return bestOverall;
  }

  enumeratePlacements(grid, pieceColors) {
    const placements = [];
    for (let rot=0; rot<4; rot++) {
      for (let x=0; x<CONFIG.COLS; x++) {
        const p = new Piece(pieceColors[0], pieceColors[1]);
        p.x = x;
        p.y = 0;
        p.rot = rot;
        if (!canPlace(grid, p.cells())) continue;
        while (canMove(p, grid, 0, 1)) p.y++;
        placements.push({x, y:p.y, rot, colors:pieceColors});
      }
    }
    return placements;
  }

  simulate(grid, placement) {
    const g = deepCloneGrid(grid);
    const p = new Piece(placement.colors[0], placement.colors[1]);
    p.x = placement.x;
    p.y = placement.y;
    p.rot = placement.rot;

    if (!canPlace(g, p.cells())) return {grid:g, chain:0, score:0, attack:0};

    placePiece(g, p);

    let totalScore = 0;
    let chain = 0;
    let guard = 0;
    while (true) {
      if (++guard > 32) break; // safety: prevent pathological loops
      const groups = findGroupsToClear(g);
      if (!groups) break;
      chain++;
      if (!groups.clearKeys || groups.clearKeys.length === 0) break;
      for (const key of groups.clearKeys) {
        const y = Math.floor(key/100);
        const x = key%100;
        g[y][x] = 0;
      }
      const score = computeChainScore(chain, groups.clearedColored, groups.colorsClearedCount, groups.groupSizes);
      totalScore += score;
      applyGravity(g);
    }
    const attack = Math.floor((totalScore / CONFIG.TARGET_POINTS) + 1e-9);
    return {grid:g, chain, score:totalScore, attack};
  }

  evaluate(sim, w, incoming, danger) {

const holes = countHoles(sim.grid, CONFIG.COLS, CONFIG.ROWS());
const maxH = maxHeight(sim.grid, CONFIG.COLS, CONFIG.ROWS());
const spawnH = this.spawnColumnHeight(sim.grid);

let links = 0;
for (let y=0; y<CONFIG.ROWS(); y++) {
  for (let x=0; x<CONFIG.COLS; x++) {
    const v = sim.grid[y][x];
    if (v === 0 || v === CONFIG.CELL_GARBAGE) continue;
    if (x+1<CONFIG.COLS && sim.grid[y][x+1]===v) links++;
    if (y+1<CONFIG.ROWS() && sim.grid[y+1][x]===v) links++;
  }
}

const clearNow = sim.chain > 0 ? 1 : 0;
const underHeavyIncoming = incoming >= 18;
const underPressure = danger || underHeavyIncoming;

// Potential (2/3-stacks) encourages long-chain building rather than accidental clears.
const clusterPot = this.clusterPotential(sim.grid);

let score = 0;

// Structure: links + potential, punish holes.
score += (links * w.link) + (clusterPot * 1.15) - (holes * w.holes);

// Height: mostly care about spawn column, not side towers.
score -= (spawnH * (w.height * 1.55) + maxH * (w.height * 0.35));

// Launch value: BIG clears only. Small clears are heavily discouraged.
if (sim.chain > 0) {
  const c = sim.chain;
  score += (c*c*c) * w.chain;
  score += (sim.score * w.score) + (sim.attack * w.attack);

  if (c < 4) {
    const penalty = (c===1 ? 120 : (c===2 ? 70 : 35));
    // Even under pressure, still discourage bailing out with tiny clears.
    score -= penalty * (underPressure ? 0.35 : 1.0);
  } else {
    score += 25 + 12 * c;
  }

  // Target 7+ chains: discourage firing 4-6 unless under pressure, reward 7+ heavily.
  if (!underPressure && c > 0 && c < 7) {
    score -= (7 - c) * 45;
  }
  if (c >= 7) {
    score += 280 + 90 * (c - 7);
  }
}

// When stacks are high but spawn is still safe, prefer continuing the build.
if (!underPressure && maxH >= 12 && spawnH <= 9 && sim.chain === 0) {
  score += 22;
}

if (danger) {
  const defense = clearNow * Math.min(1, incoming/12);
  score += (defense * w.garbage * 9);
  score -= (spawnH * w.safety * 1.2) + (holes * w.safety * 0.5);
}

score -= Math.abs((CONFIG.COLS-1)/2 - this.columnCenter(sim.grid)) * 0.12;
return score;
  }

columnCenter(grid) {
  let sum=0, cnt=0;
  for (let y=0; y<CONFIG.ROWS(); y++) {
    for (let x=0; x<CONFIG.COLS; x++) {
      if (grid[y][x] !== 0) { sum += x; cnt++; }
    }
  }
  return cnt ? sum/cnt : (CONFIG.COLS-1)/2;
}

columnHeight(grid, col) {
  const rows = CONFIG.ROWS();
  for (let y=0; y<rows; y++) {
    if (grid[y][col] !== 0) return rows - y;
  }
  return 0;
}

spawnColumnHeight(grid) {
  const spawnCol = Math.floor((CONFIG.COLS-1)/2);
  return this.columnHeight(grid, spawnCol);
}

// Reward "in-progress" groups (size 2/3) that help form large chains,
// and gently penalize scattered singles.
clusterPotential(grid) {
  const rows = CONFIG.ROWS();
  const cols = CONFIG.COLS;
  const visited = Array.from({length: rows}, () => Array(cols).fill(false));
  let pot = 0;

  const dirs = [[1,0],[-1,0],[0,1],[0,-1]];

  for (let y=0; y<rows; y++) {
    for (let x=0; x<cols; x++) {
      const v = grid[y][x];
      if (v === 0 || v === CONFIG.CELL_GARBAGE) continue;
      if (visited[y][x]) continue;

      const q = [[x,y]];
      visited[y][x] = true;
      const cells = [];
      while (q.length) {
        const [cx,cy] = q.pop();
        cells.push([cx,cy]);
        for (const [dx,dy] of dirs) {
          const nx=cx+dx, ny=cy+dy;
          if (nx<0||nx>=cols||ny<0||ny>=rows) continue;
          if (visited[ny][nx]) continue;
          if (grid[ny][nx] !== v) continue;
          visited[ny][nx] = true;
          q.push([nx,ny]);
        }
      }

      const sz = cells.length;

      if (sz === 1) {
        pot -= 0.25;
        continue;
      }

      if (sz === 2) pot += 2.4;
      else if (sz === 3) pot += 7.5;

      let adjEmpty = 0;
      for (const [cx,cy] of cells) {
        for (const [dx,dy] of dirs) {
          const nx=cx+dx, ny=cy+dy;
          if (nx<0||nx>=cols||ny<0||ny>=rows) continue;
          if (grid[ny][nx] === 0) adjEmpty++;
        }
      }
      pot += Math.min(6, adjEmpty) * (sz === 3 ? 0.35 : 0.18);
    }
  }
  return pot;
}

  buildPlan(first) {
    return {
      targetRot:first.rot,
      targetX:first.x,
      hardDrop:false
    };
  }
}

// ---------- Game ----------
class Game {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.dpr = Math.max(1, Math.min(2, window.devicePixelRatio || 1));
    this.resize();

    this.input = new Input(canvas);

    const seed = (Date.now() ^ 0x9e3779b9) >>> 0;
    this.rng = mulberry32(seed);

    this.audio = new AudioBank();
    // Achievements (simple local save)
    this.ach = {
      allClear: (localStorage.getItem('bdvs_ach_allclear') === '1')
    };
    window.__audio = this.audio;

    this.cpuDifficulty = 4;
    this.fallSpeed = 'slow';
    this.playerLockDelayFrames = 32; // 32 frames (Tsu-like)
    this.cpuLockDelayFrames = 32;     // match player
    this.lockDelayFrames = this.playerLockDelayFrames; // legacy binding for UI
    this.garbageCap = CONFIG.GARBAGE_CAP_PER_DROP;
    this.marginOn = false;
    this.zenkeshiOn = true;
    this.playerOnRight = true; // start on right (enemy chain voice)

    this.marginStartMs = 120000;
    this.startedAt = now();

    this.aiPlanner = new AIPlanner();

    this.reset();

    this.paused = false;
    this.gameOver = false;
    this.pendingEnd = null;
    this.freezeForEnd = false;

    this._last = now();
    // Cancels in-flight async resolution tasks (chain/garbage/spawn) when the round ends or restarts.
    this.epoch = 0;
    requestAnimationFrame(()=>this.loop());;
  }

  resize() {
    const rect = this.canvas.getBoundingClientRect();
    const w = Math.floor(rect.width * this.dpr);
    const h = Math.floor((rect.width * 9/16) * this.dpr);
    this.canvas.width = clamp(w, 900, 2200);
    this.canvas.height = clamp(h, 520, 1400);
  }


  toast(msg) {
    this._toast = { t0: now(), msg: String(msg || '') };
  }

  unlockAllClearAchievement() {
    if (!this.ach) this.ach = { allClear: false };
    if (!this.ach.allClear) {
      this.ach.allClear = true;
      try { localStorage.setItem('bdvs_ach_allclear', '1'); } catch (_) {}
    }
    this.toast('Achievement unlocked: All Clear!');
  }

  cheatAllClear() {
    const side = this.player;
    if (!side) return;
    // Clear ONLY the placed board; keep the active falling pair.
    side.grid = makeEmptyGrid();
    // Arm the all-clear bonus as if you achieved a Zenkeshi naturally.
    side.allClearArmed = true;
    this.unlockAllClearAchievement();
  }

  reset() {
    // Cancel any in-flight async resolution tasks from a previous round.
    this.epoch++;
    this.startedAt = now();
    this.gameOver = false;
    this.pendingEnd = null;
    this.freezeForEnd = false;

    this.player = new Side('Player', false, this.rng);
    this.cpu = new Side('CPU', true, this.rng);
    this.updateBoardSides();

    this.player.ensureNext();
    this.cpu.ensureNext();
    this.player.spawn();
    this.cpu.spawn();

    this.aiPlanner.compute(this.cpu, this.player, this.cpuDifficulty);

    this.setOverlay(null);
    this.updateHUD();
  }


  updateBoardSides() {
    // Left board always uses normal chain voice; right board uses enemy chain voice.
    this.player.boardSide = this.playerOnRight ? 'right' : 'left';
    this.cpu.boardSide = this.playerOnRight ? 'left' : 'right';
  }

  setPlayerSide(side) {
    this.playerOnRight = (side === 'right');
    this.updateBoardSides();
  }

  setOverlay(kind, title, body) {
    const overlay = document.getElementById('overlay');
    const t = document.getElementById('overlayTitle');
    const b = document.getElementById('overlayBody');
    if (!kind) {
      overlay.classList.add('hidden');
      return;
    }
    overlay.classList.remove('hidden');
    t.textContent = title || 'Paused';
    b.textContent = body || '';
  }

  updateHUD() {
    const pState = document.getElementById('pState');
    const aiState = document.getElementById('aiState');
    const pGarbage = document.getElementById('pGarbage');
    const aiGarbage = document.getElementById('aiGarbage');
    const marginTime = document.getElementById('marginTime');
    const allClear = document.getElementById('allClear');
    pState.textContent = this.player.stateLabel;
    aiState.textContent = this.aiPlanner.state;
    pGarbage.textContent = String((this.player.pendingGarbage|0) + (this.player.pendingGarbageNext|0));
    aiGarbage.textContent = String((this.cpu.pendingGarbage|0) + (this.cpu.pendingGarbageNext|0));
    marginTime.textContent = this.marginOn ? 'On' : 'Off';
    allClear.textContent = this.zenkeshiOn ? 'On' : 'Off';
  }


  loop() {
    try {
      const t = now();
      let dt = (t - this._last);
      this._last = t;

      dt = Math.min(dt, 50);
      const dtFrames = dt * CONFIG.FPS / 1000;

      if (!this.paused && !this.gameOver) {
        this.step(dt, dtFrames);
      }
      this.draw();
      // If an end was requested during an async chain, finalize once both sides finish resolving.
      if (this.pendingEnd && !this.gameOver && !this.player?.isResolving && !this.cpu?.isResolving) {
        const pe = this.pendingEnd;
        this.pendingEnd = null;
        this.freezeForEnd = false;
        this._finalizeEndGame(pe.title, pe.body);
      }
    } catch (e) {
      console.error('Loop error', e);
      this.antifreezeGlobal(e);
    } finally {
      this.input.beginFrame();
      requestAnimationFrame(()=>this.loop());;
    }
  }

  step(dtMs, dtFrames) {
    if (this.freezeForEnd || this.pendingEnd) {
      // Freeze controls/physics while allowing any in-flight chain resolution visuals to finish.
      return;
    }
    if (this.marginOn) {
      const elapsed = now() - this.startedAt;
      if (elapsed > this.marginStartMs) {
        const t = clamp((elapsed - this.marginStartMs) / (240000), 0, 1);
        CONFIG.TARGET_POINTS = Math.round(lerp(70, 20, t));
      } else {
        CONFIG.TARGET_POINTS = 70;
      }
    } else {
      CONFIG.TARGET_POINTS = 70;
    }

    this.controlPlayer(dtFrames);
    this.controlCpu(dtFrames);

    this.fallSide(this.player, dtMs, dtFrames);
    this.fallSide(this.cpu, dtMs, dtFrames);

    this.updateHUD();
  }

  controlPlayer(dtFrames) {
    const side = this.player;
    // Cheat: instant all-clear + achievement.
    if (this.input.wasPressed('t') && !this.gameOver) {
      this.cheatAllClear();
    }
    const p = side.active;
    if (!p) return;

    const das = CONFIG.INPUT_DAS_FRAMES;
    const arr = CONFIG.INPUT_ARR_FRAMES;

    const left = this.input.repeatPressed('arrowleft', dtFrames, das, arr);
    const right = this.input.repeatPressed('arrowright', dtFrames, das, arr);

    if (left && canMove(p, side.grid, -1, 0)) { p.x -= 1; this.audio.playSfx('move'); }
    if (right && canMove(p, side.grid, 1, 0)) { p.x += 1; this.audio.playSfx('move'); }

    // Requested: swap Z and X rotation directions.
    if (this.input.wasPressed('z') && canRotate(p, side.grid, +1)) { applyRotate(p, side.grid, +1); this.audio.playSfx('rotate'); }
    if (this.input.wasPressed('x') && canRotate(p, side.grid, -1)) { applyRotate(p, side.grid, -1); this.audio.playSfx('rotate'); }

    const hard = this.input.wasPressed('arrowup') || this.input.wasPressed(' ');
    if (hard) {
      const d = hardDropDistance(p, side.grid);
      p.y += d;
      this.lockAndResolve(side);
      return;
    }
  }

  controlCpu(dtFrames) {
    const side = this.cpu;
    const p = side.active;
    if (!p) return;

    side.cpuSoftDrop = false;

    if (!this.aiPlanner.plan || (side.pendingGarbage >= 18 && this.aiPlanner.state !== 'Counteract')) {
      this.aiPlanner.compute(side, this.player, this.cpuDifficulty);
    }
    const plan = this.aiPlanner.plan;
    if (!plan) return;

    const rotDiff = (plan.targetRot - p.rot + 4) % 4;
    if (rotDiff !== 0) {
      const dir = rotDiff === 3 ? -1 : +1;
      if (canRotate(p, side.grid, dir)) applyRotate(p, side.grid, dir);
      return;
    }
    if (p.x < plan.targetX) { if (canMove(p, side.grid, 1, 0)) p.x += 1; return; }
    if (p.x > plan.targetX) { if (canMove(p, side.grid, -1, 0)) p.x -= 1; return; }
    // No hard drop for CPU (requested).
    // Allow CPU to use SOFT drop once aligned to its target.
    side.cpuSoftDrop = true;
  }

  fallSide(side, dtMs, dtFrames) {
    const p = side.active;
    if (!p) return;

    const soft = (!side.isCpu && this.input.isDown('arrowdown')) || (side.isCpu && side.cpuSoftDrop);
    const gravity = CONFIG.GRAVITY_CELLS_PER_SEC[this.fallSpeed] * (soft ? CONFIG.SOFT_DROP_MULT : 1.0) * (side.isCpu ? CONFIG.CPU_FALL_MULT : 1.0);
    side._fallAcc = (side._fallAcc || 0) + gravity * (dtMs/1000);

    const lockDelay = side.isCpu ? this.cpuLockDelayFrames : this.playerLockDelayFrames;
    // Apply vertical movement based on accumulated gravity
    let moved = false;
    while (side._fallAcc >= 1) {
      side._fallAcc -= 1;
      if (canMove(p, side.grid, 0, 1)) {
        p.y += 1;
        moved = true;
      } else {
        break;
      }
    }

    if (moved) {
      // If we actually fell this frame, we are not grounded.
      p.lockTimer = 0;
      return;
    }

    // Grounded: handle locking using real time (frames), not gravity steps.
    if (!canMove(p, side.grid, 0, 1)) {
      if (soft) {
        // Soft drop locks immediately on contact (classic feel).
        this.lockAndResolve(side);
        return;
      }
      p.lockTimer = (p.lockTimer || 0) + dtFrames;
      if (p.lockTimer >= lockDelay) {
        this.lockAndResolve(side);
        return;
      }
    }
}

  async lockAndResolve(side) {
    if (!side.active) return;
    if (side.isResolving) return;
    side.isResolving = true;
    const epoch = this.epoch;
    try {
    if (this.gameOver || epoch !== this.epoch) return;
    this.audio.playSfx('lock');
    side.lockActive();
    applyGravity(side.grid);

    let chain = 0;
    let chainTotalScore = 0;

    let groups = findGroupsToClear(side.grid);
    while (groups) {
      chain++;
      if (!groups.clearKeys || groups.clearKeys.length === 0) break;
      this.audio.playSfx('pop');
      this.audio.playChain(chain, side.boardSide === 'right');

      // Visual chain effects (polished pop + chain text + flash)
      this.spawnChainFx(side, groups, chain);

      for (const key of groups.clearKeys) {
        const y = Math.floor(key/100);
        const x = key%100;
        side.grid[y][x] = 0;
      }

      const score = computeChainScore(chain, groups.clearedColored, groups.colorsClearedCount, groups.groupSizes);
      chainTotalScore += score;
      side.score += score;

      await this.sleep(CONFIG.CHAIN_POP_PAUSE_MS);
      if (this.gameOver || epoch !== this.epoch) return;
      applyGravity(side.grid);
      await this.sleep(CONFIG.CHAIN_FALL_PAUSE_MS);
      if (this.gameOver || epoch !== this.epoch) return;

      const nextGroups = findGroupsToClear(side.grid);
      if (nextGroups) {
        await this.sleep(CONFIG.CHAIN_STEP_DELAY_MS);
        if (this.gameOver || epoch !== this.epoch) return;
      }
      groups = nextGroups;
    }

    // If the round ended during someone else's chain, stop here after finishing the visual/clear steps.
    if (this.pendingEnd || this.freezeForEnd) return;

    let sent = 0;
    if (chainTotalScore > 0) {
      let bonus = 0;
      if (this.zenkeshiOn && side.allClearArmed) {
        bonus += CONFIG.ALL_CLEAR_BONUS;
        side.allClearArmed = false;
      }
      const res = nuisanceFromScore(chainTotalScore, side.sentCarry);
      sent = res.send + bonus;
      side.sentCarry = res.carry;
    }
    if (this.zenkeshiOn && isAllClear(side.grid)) side.allClearArmed = true;

    // ---- Continuous play fight-back (Tsu-style offset) + garbage grace + spawn pipeline ----
    const opp = (side === this.player) ? this.cpu : this.player;

    // 1) First, use this attack to cancel THIS side's incoming garbage (armed first, then next-turn-armed).
    let atk = sent|0;
    if (atk > 0 && side.pendingGarbage > 0) {
      const c1 = Math.min(atk, side.pendingGarbage);
      side.pendingGarbage -= c1;
      atk -= c1;
    }
    if (atk > 0 && side.pendingGarbageNext > 0) {
      const c2 = Math.min(atk, side.pendingGarbageNext);
      side.pendingGarbageNext -= c2;
      atk -= c2;
    }

    // 2) Remaining attack becomes outgoing nuisance waiting for offset with opponent's outgoing.
    if (atk > 0) side.attackPending = (side.attackPending|0) + atk;

    // 3) Apply mutual offset so "whoever resolves first" doesn't change the result.
    const cancelMut = Math.min(this.player.attackPending|0, this.cpu.attackPending|0);
    if (cancelMut > 0) {
      this.player.attackPending -= cancelMut;
      this.cpu.attackPending -= cancelMut;
    }

    // 4) Deliver any net remaining attack to the opponent with grace:
    //    if opponent is currently resolving, it becomes next-turn-armed (cannot drop in the same resolution window).
    if ((this.player.attackPending|0) > 0) {
      const amt = this.player.attackPending|0;
      if (this.cpu.isResolving) this.cpu.pendingGarbageNext = (this.cpu.pendingGarbageNext|0) + amt;
      else this.cpu.pendingGarbage = (this.cpu.pendingGarbage|0) + amt;
      this.player.attackPending = 0;
    }
    if ((this.cpu.attackPending|0) > 0) {
      const amt = this.cpu.attackPending|0;
      if (this.player.isResolving) this.player.pendingGarbageNext = (this.player.pendingGarbageNext|0) + amt;
      else this.player.pendingGarbage = (this.player.pendingGarbage|0) + amt;
      this.cpu.attackPending = 0;
    }

// Drop only the garbage that is currently eligible for this side (already armed before this turn ended).
    await this.sleep(CONFIG.GARBAGE_DROP_PAUSE_MS);
    if (this.gameOver || epoch !== this.epoch) return;
    if (side.pendingGarbage > 0) {
      const dropNow = Math.min(side.pendingGarbage, this.garbageCap);
      dropGarbage(side.grid, dropNow, this.rng);
      side.pendingGarbage = Math.max(0, side.pendingGarbage - dropNow);
      applyGravity(side.grid);
    }

    // Spawn next piece after nuisance phase.
    if (this.pendingEnd || this.freezeForEnd) return;
    await this.sleep(CONFIG.SPAWN_DELAY_MS);
    if (this.gameOver || epoch !== this.epoch) return;
    if (!side.spawn()) {
      this.endGame(side === this.player ? 'CPU wins' : 'Player wins', 'Top-out!');
      return;
    }
    if (side.visibleTopOut()) {
      this.endGame(side === this.player ? 'CPU wins' : 'Player wins', 'Top-out!');
      return;
    }

    // Arm any nuisance that was queued during this side's resolution for the NEXT turn.
    if (side.pendingGarbageNext > 0) {
      side.pendingGarbage = (side.pendingGarbage|0) + (side.pendingGarbageNext|0);
      side.pendingGarbageNext = 0;
    }

    if (side.isCpu) this.aiPlanner.compute(this.cpu, this.player, this.cpuDifficulty);
    return;
    } catch (e) {
      console.error('lockAndResolve error', e);
      this.antifreezeGlobal(e);
    } finally {
      side.isResolving = false;
    }
  }

  endGame(title, body) {
    // If a player tops out while a chain is still resolving, let the chain finish first.
    if (this.gameOver) return;

    if (this.player?.isResolving || this.cpu?.isResolving) {
      // Defer the overlay until both sides finish resolving.
      if (!this.pendingEnd) this.pendingEnd = { title, body };
      this.freezeForEnd = true;
      return;
    }
    this._finalizeEndGame(title, body);
  }

  _finalizeEndGame(title, body) {
    if (this.gameOver) return;
    this.gameOver = true;
    // Cancel any in-flight async resolution tasks AFTER we’ve allowed chains to finish.
    this.epoch++;
    this.setOverlay('gameover', title, body);
  }

  // ---- Anti-freeze watchdog -------------------------------------------------
  // -------------------------------------------------
  // If an exception happens mid-resolution, we can get stuck with isResolving=true
  // and no active piece. This recovers by unblocking the pipeline and spawning again.
  antifreezeGlobal(err) {
    // Avoid spamming recoveries every frame.
    const t = now();
    if (this._lastAntifreeze && (t - this._lastAntifreeze) < 500) return;
    this._lastAntifreeze = t;

    this._freezeCount = (this._freezeCount || 0) + 1;

    try {
      // Clear any resolving flags that might have stranded a side.
      this.antifreezeSide(this.player, err);
      this.antifreezeSide(this.cpu, err);

      // Re-plan CPU if needed.
      if (!this.gameOver && this.cpu && this.cpu.isCpu) {
        try { this.aiPlanner.compute(this.cpu, this.player, this.cpuDifficulty); } catch (_) {}
      }

      // Tiny on-screen hint (non-blocking).
      this._toast = { t0: t, msg: 'Recovered from a hiccup' };
    } catch (e) {
      console.error('Antifreeze failed', e);
    }
  }

  antifreezeSide(side, err) {
    if (!side) return;
    // If we crashed inside lockAndResolve, unblock.
    if (side.isResolving) side.isResolving = false;

    // If there is no active piece, spawn one so the game continues.
    if (!side.active && !this.gameOver) {
      // Arm queued nuisance so it doesn't vanish.
      if (side.pendingGarbageNext > 0) {
        side.pendingGarbage = (side.pendingGarbage|0) + (side.pendingGarbageNext|0);
        side.pendingGarbageNext = 0;
      }
      const ok = side.spawn();
      if (!ok) {
        this.endGame(side === this.player ? 'CPU wins' : 'Player wins', 'Top-out!');
      }
    }
  }

  sleep(ms) { return new Promise(res=>setTimeout(res, ms)); }
  // Sleep helper used inside resolution tasks. Callers should check epoch after awaiting.
  sleepChecked(ms, epoch) {
    return new Promise(res=>setTimeout(()=>res(epoch === this.epoch), ms));
  }

  getChainAnimImage(chain) {
    if (!this.chainAnimImgs || !this.chainAnimImgs.length) return null;
    const idx = (chain <= 6) ? (chain - 1) : 6; // 7+ uses 6plus
    return this.chainAnimImgs[idx] || null;
  }

  spawnChainFx(side, groups, chain) {
    const t0 = now();
    // Flash scales with chain length.
    side._flash = { t0, dur: 240 + Math.min(360, chain*60), chain };

    // Per-cell pop sprites.
    for (const key of groups.clearKeys) {
      const y = Math.floor(key/100);
      const x = key%100;
      const v = side.grid[y][x];
      if (v === 0) continue;
      const seed = hash32(x, y, chain);
      side.fx.push({ kind:'pop', x, y, v, chain, t0, dur: 420, seed });
    }

    // Premade chain animation overlay (falls back to text if missing).
    if (this.chainAnimImgs && this.chainAnimImgs.length) {
      side.fx.push({ kind:'chainimg', chain, t0, dur: 720 });
    } else {
      side.fx.push({ kind:'text', chain, t0, dur: 1200 + Math.min(900, chain*120) });
    }
  }

  drawSideFx(ctx, side, x0, y0, cell, playW, playH) {
    const t = now();
    if (side.fx.length) side.fx = side.fx.filter(f => (t - f.t0) < f.dur);

    // Flash overlay
    if (side._flash && (t - side._flash.t0) < side._flash.dur) {
      const p = (t - side._flash.t0) / side._flash.dur;
      const a = 0.22 * (1 - easeOutCubic(p));
      ctx.save();
      ctx.globalAlpha = a;
      ctx.globalCompositeOperation = 'screen';
      const gx = x0, gy = y0, gw = playW, gh = playH;
      const grad = ctx.createLinearGradient(gx, gy, gx, gy+gh);
      grad.addColorStop(0, 'rgba(255,255,255,0.9)');
      grad.addColorStop(1, 'rgba(120,180,255,0.1)');
      ctx.fillStyle = grad;
      ctx.fillRect(gx, gy, gw, gh);
      ctx.restore();
    }

    // Pops + sparkles
    for (const f of side.fx) {
      if (f.kind !== 'pop') continue;
      const dt = (t - f.t0) / f.dur;
      const p = clamp(dt,0,1);
      const vy = f.y - CONFIG.HIDDEN_ROWS;
      if (vy < 0) continue;
      const cx = x0 + f.x*cell + cell/2;
      const cy = y0 + vy*cell + cell/2;

      const scale = lerp(1.0, 1.75, easeOutCubic(p));
      const alpha = 1.0 - easeOutCubic(p);
      const rot = (((f.seed & 1023) / 1023) - 0.5) * 0.55 * (1.0 - p);

      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(rot);
      ctx.scale(scale, scale);
      this.drawCell(ctx, -cell/2, -cell/2, cell, f.v, 0.95*alpha);
      ctx.restore();

      // Sparkles
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = 0.65 * alpha;
      for (let i=0; i<6; i++) {
        const s = hash32(f.seed, i, 911);
        const ang = ((s & 4095) / 4095) * Math.PI*2;
        const rad = lerp(cell*0.15, cell*0.75, easeOutCubic(p));
        const sx = cx + Math.cos(ang) * rad;
        const sy = cy + Math.sin(ang) * rad;
        const r = lerp(cell*0.12, cell*0.02, p);
        ctx.fillStyle = 'rgba(255,255,255,1)';
        ctx.beginPath();
        ctx.arc(sx, sy, r, 0, Math.PI*2);
        ctx.fill();
      }
      ctx.restore();
    }

    // Premade chain animation overlay
    const chainFx = side.fx.filter(f => f.kind === 'chainimg');
    for (const f of chainFx) {
      const img = this.getChainAnimImage(f.chain);
      if (!img) continue;
      const p = clamp((t - f.t0) / f.dur, 0, 1);
      const a = 1 - easeInOutQuad(p);
      const sc = lerp(0.86, 1.06, easeOutCubic(Math.min(1, p*1.3)));
      const rise = lerp(cell*0.25, -cell*0.35, easeOutCubic(p));

      // Scale to fit nicely in the play area.
      const maxW = playW * 0.78;
      const maxH = playH * 0.58;
      const s = Math.min(maxW / img.width, maxH / img.height) * sc;
      const dw = img.width * s;
      const dh = img.height * s;
      const dx = x0 + (playW - dw)/2;
      const dy = y0 + playH*0.30 + rise - dh/2;

      ctx.save();
      ctx.globalAlpha = 0.95 * a;
      ctx.globalCompositeOperation = 'screen';
      ctx.drawImage(img, dx, dy, dw, dh);
      ctx.restore();
    }

    // Fallback chain text (if any)
    const textFx = side.fx.filter(f => f.kind === 'text');
    for (const f of textFx) {
      const p = clamp((t - f.t0)/f.dur, 0, 1);
      const a = 1 - easeInOutQuad(p);
      const rise = lerp(0, -cell*1.2, easeOutCubic(p));
      const sc = lerp(0.8, 1.15, easeOutCubic(Math.min(1, p*1.2)));

      ctx.save();
      ctx.translate(x0 + playW/2, y0 + playH*0.32 + rise);
      ctx.scale(sc, sc);
      ctx.globalAlpha = 0.85 * a;
      ctx.globalCompositeOperation = 'screen';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      const fs = Math.floor(cell*0.95);
      ctx.font = `800 ${fs}px ui-sans-serif, system-ui`;
      ctx.lineWidth = 6*this.dpr;
      ctx.strokeStyle = 'rgba(0,0,0,0.55)';
      ctx.fillStyle = 'rgba(255,255,255,0.95)';
      const label = `${f.chain} CHAIN`;
      ctx.strokeText(label, 0, 0);
      ctx.fillText(label, 0, 0);
      ctx.restore();
    }
  }

  draw() {
    const ctx = this.ctx;
    const W = this.canvas.width;
    const H = this.canvas.height;
    ctx.clearRect(0,0,W,H);

    ctx.save();
    ctx.globalAlpha = 0.18;
    ctx.fillStyle = '#000';
    for (let y=0; y<H; y+=4) ctx.fillRect(0,y,W,1);
    ctx.restore();

    const pad = 26 * this.dpr;
    const boardW = (W - pad*3) / 2;
    const boardH = H - pad*2;
    const cell = Math.floor(Math.min(boardW / (CONFIG.COLS + 4), boardH / (CONFIG.VISIBLE_ROWS + 2)));
    const playW = cell * CONFIG.COLS;

    const leftX = pad + Math.floor((boardW - playW) / 2);
    const rightX = pad*2 + boardW + Math.floor((boardW - playW) / 2);
    const topY = pad + cell;

    const leftSide = this.playerOnRight ? this.cpu : this.player;
    const rightSide = this.playerOnRight ? this.player : this.cpu;
    this.drawSide(ctx, leftSide, leftX, topY, cell);
    this.drawSide(ctx, rightSide, rightX, topY, cell);

    ctx.save();
    ctx.fillStyle = 'rgba(255,255,255,.12)';
    ctx.fillRect(W/2 - 1, pad, 2, H-pad*2);
    // Antifreeze toast (non-blocking)
    if (this._toast) {
      const t = now();
      const age = t - this._toast.t0;
      if (age < 1200) {
        const p = age / 1200;
        const a = 1 - p;
        ctx.save();
        ctx.globalAlpha = 0.85 * a;
        ctx.fillStyle = 'rgba(0,0,0,.55)';
        ctx.fillRect(16*this.dpr, 16*this.dpr, 280*this.dpr, 34*this.dpr);
        ctx.fillStyle = 'rgba(255,255,255,.95)';
        ctx.font = `${14*this.dpr}px system-ui, sans-serif`;
        ctx.fillText(this._toast.msg, 28*this.dpr, 39*this.dpr);
        ctx.restore();
      } else {
        this._toast = null;
      }
    }

    ctx.restore();
  }

  drawSide(ctx, side, x0, y0, cell) {
    const playW = cell * CONFIG.COLS;
    const playH = cell * CONFIG.VISIBLE_ROWS;

    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,.35)';
    ctx.fillRect(x0-10, y0-10, playW+20, playH+20);

    ctx.fillStyle = 'rgba(10,14,26,.55)';
    ctx.strokeStyle = 'rgba(255,255,255,.12)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    roundRect(ctx, x0-6, y0-6, playW+12, playH+12, 18);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = 'rgba(255,255,255,.9)';
    ctx.font = `${Math.floor(16*this.dpr)}px ui-sans-serif, system-ui`;
    ctx.fillText(side.name, x0, y0 - 18*this.dpr);

    ctx.fillStyle = 'rgba(255,255,255,.65)';
    ctx.font = `${Math.floor(12*this.dpr)}px ui-monospace, SFMono-Regular`;
    ctx.fillText(`Garbage: ${side.pendingGarbage}`, x0 + playW - 130*this.dpr, y0 - 18*this.dpr);

    ctx.fillStyle = 'rgba(0,0,0,.22)';
    ctx.fillRect(x0, y0, playW, playH);

    for (let vy=0; vy<CONFIG.VISIBLE_ROWS; vy++) {
      const y = vy + CONFIG.HIDDEN_ROWS;
      for (let x=0; x<CONFIG.COLS; x++) {
        const v = side.grid[y][x];
        if (v === 0) {
          ctx.strokeStyle = 'rgba(255,255,255,.045)';
          ctx.strokeRect(x0 + x*cell + 0.5, y0 + vy*cell + 0.5, cell, cell);
          continue;
        }
        this.drawCell(ctx, x0 + x*cell, y0 + vy*cell, cell, v);
      }
    }

    if (side.active) {
      this.drawGhost(ctx, side, x0, y0, cell);
      for (const c of side.active.cells()) {
        const vy = c.y - CONFIG.HIDDEN_ROWS;
        if (vy < 0) continue;
        this.drawCell(ctx, x0 + c.x*cell, y0 + vy*cell, cell, c.v);
      }
    }

    // Chain pop animations + chain number/flash.
    this.drawSideFx(ctx, side, x0, y0, cell, playW, playH);

    side.ensureNext();
    const nx = x0 + playW + 14*this.dpr;
    const ny = y0 + 8*this.dpr;
    ctx.fillStyle = 'rgba(255,255,255,.75)';
    ctx.font = `${Math.floor(12*this.dpr)}px ui-monospace, SFMono-Regular`;
    ctx.fillText('NEXT', nx, ny);
    for (let i=0; i<2; i++) {
      const pair = side.next[i];
      if (!pair) continue;
      // Preview matches spawn orientation (satellite above pivot at rot=0).
      this.drawCell(ctx, nx, ny + 12*this.dpr + i*cell*2, cell, pair[1], 0.9);
      this.drawCell(ctx, nx, ny + 12*this.dpr + i*cell*2 + cell, cell, pair[0], 0.9);
    }

    ctx.restore();
  }

  drawGhost(ctx, side, x0, y0, cell) {
    const p = side.active;
    const ghost = new Piece(p.pivot, p.sat);
    ghost.x = p.x;
    ghost.y = p.y;
    ghost.rot = p.rot;
    while (canMove(ghost, side.grid, 0, 1)) ghost.y++;
    ctx.save();
    ctx.globalAlpha = 0.14;
    ctx.filter = 'blur(0.9px)';
    for (const c of ghost.cells()) {
      const vy = c.y - CONFIG.HIDDEN_ROWS;
      if (vy < 0) continue;
      this.drawCell(ctx, x0 + c.x*cell, y0 + vy*cell, cell, c.v);
    }
    ctx.restore();
  }

  drawCell(ctx, x, y, cell, v, alpha=1.0) {
    ctx.save();
    ctx.globalAlpha = alpha;

    if (v === CONFIG.CELL_GARBAGE) {
      if (this.garbageImg) {
        const iw = this.garbageImg.width, ih = this.garbageImg.height;
        const scale = Math.min(cell/iw, cell/ih);
        const w = iw * scale, h = ih * scale;
        const dx = x + (cell - w)/2;
        const dy = y + (cell - h)/2;
        ctx.drawImage(this.garbageImg, dx, dy, w, h);
      } else {
        // Fallback: simple neutral garbage blob (no X)
        const r = cell*0.46;
        const cx = x + cell/2, cy = y + cell/2;
        ctx.fillStyle = 'rgba(210,215,235,.92)';
        ctx.beginPath();
        ctx.ellipse(cx, cy, r*1.05, r*0.95, 0, 0, Math.PI*2);
        ctx.fill();
        ctx.fillStyle = 'rgba(0,0,0,.20)';
        ctx.beginPath();
        ctx.ellipse(cx, cy+2*this.dpr, r*0.95, r*0.85, 0, 0, Math.PI*2);
        ctx.fill();
        ctx.strokeStyle = 'rgba(20,30,50,.35)';
        ctx.lineWidth = 2*this.dpr;
        ctx.stroke();
      }
      ctx.restore();
      return;
    }

    const colorName = CONFIG.COLORS[v-1];
    const rect = SPRITES[colorName];
    if (!this.sheetImg) {
      ctx.fillStyle = 'rgba(255,255,255,.75)';
      ctx.fillRect(x,y,cell,cell);
      ctx.restore();
      return;
    }
    ctx.imageSmoothingEnabled = true;
    ctx.drawImage(this.sheetImg, rect.x, rect.y, rect.w, rect.h, x, y, cell, cell);
    ctx.fillStyle = 'rgba(255,255,255,.06)';
    ctx.fillRect(x, y, cell, cell*0.45);
    ctx.restore();
  }
}

function roundRect(ctx, x, y, w, h, r) {
  const rr = Math.min(r, w/2, h/2);
  ctx.moveTo(x+rr, y);
  ctx.arcTo(x+w, y, x+w, y+h, rr);
  ctx.arcTo(x+w, y+h, x, y+h, rr);
  ctx.arcTo(x, y+h, x, y, rr);
  ctx.arcTo(x, y, x+w, y, rr);
  ctx.closePath();
}

// ---------- Boot ----------
async function loadImage(src) {
  return new Promise((res, rej) => {
    const img = new Image();
    img.onload = () => res(img);
    img.onerror = rej;
    img.src = src;
  });
}

function hookUI(game) {
  const byId = (id)=>document.getElementById(id);

  byId('btnPause').addEventListener('click', ()=>togglePause());
  byId('btnRestart').addEventListener('click', ()=>game.reset());
  byId('btnSettings').addEventListener('click', ()=>showSettings(true));
  byId('btnCloseSettings').addEventListener('click', ()=>showSettings(false));

  byId('overlayResume').addEventListener('click', ()=>togglePause(false));
  byId('overlayRestart').addEventListener('click', ()=>{ togglePause(false); game.reset(); });

  byId('btnMusic').addEventListener('click', ()=>{
    game.audio.unlock();
    game.audio.setMusic(!game.audio.musicOn);
    byId('btnMusic').textContent = `Music: ${game.audio.musicOn?'On':'Off'}`;
  });
  byId('btnSfx').addEventListener('click', ()=>{
    game.audio.setSfx(!game.audio.sfxOn);
    byId('btnSfx').textContent = `SFX: ${game.audio.sfxOn?'On':'Off'}`;
  });

  byId('cpuDifficulty').addEventListener('change', (e)=>{
    game.cpuDifficulty = parseInt(e.target.value,10);
    game.aiPlanner.compute(game.cpu, game.player, game.cpuDifficulty);
  });
  byId('fallSpeed').addEventListener('change', (e)=>{ game.fallSpeed = e.target.value; });
  byId('playerSide').addEventListener('change', (e)=>{ game.setPlayerSide(e.target.value); });
  byId('lockDelay').addEventListener('change', (e)=>{ game.playerLockDelayFrames = parseInt(e.target.value,10); game.lockDelayFrames = game.playerLockDelayFrames; });
  byId('garbageCap').addEventListener('change', (e)=>{ game.garbageCap = parseInt(e.target.value,10); });
  byId('margin').addEventListener('change', (e)=>{ game.marginOn = (e.target.value === 'on'); });
  byId('zenkeshi').addEventListener('change', (e)=>{ game.zenkeshiOn = (e.target.value === 'on'); });

  function showSettings(on) {
    byId('settings').classList.toggle('hidden', !on);
  }

  function togglePause(force) {
    if (typeof force === 'boolean') game.paused = !force ? false : true;
    else game.paused = !game.paused;
    if (game.paused) game.setOverlay('pause', 'Paused', 'Press P to resume.');
    else game.setOverlay(null);
  }

  window.addEventListener('keydown', (e)=>{
    const k = e.key.toLowerCase();
    if (k === 'p') togglePause();
    if (k === 'r') game.reset();
  });
}

(async function main() {
  const canvas = document.getElementById('game');
  const game = new Game(canvas);
  window.__game = game;

  // Antifreeze: keep the loop alive even if an async task throws.
  window.addEventListener('error', (ev)=>{
    try { if (window.__game) window.__game.antifreezeGlobal(ev.error || ev.message || ev); } catch(_) {}
  });
  window.addEventListener('unhandledrejection', (ev)=>{
    try { if (window.__game) window.__game.antifreezeGlobal(ev.reason || ev); } catch(_) {}
  });

  try { game.sheetImg = await loadImage(ASSETS.sheet); } catch (e) { console.warn('Could not load puyo_sheet.png', e); }
  try { game.garbageImg = await loadImage(ASSETS.garbage); } catch (e) { console.warn('Could not load garbage.png', e); }
  // Load premade chain animations (optional).
  game.chainAnimImgs = [];
  if (ASSETS.chainAnim && ASSETS.chainAnim.length) {
    for (const src of ASSETS.chainAnim) {
      try { game.chainAnimImgs.push(await loadImage(src)); }
      catch (e) { console.warn('Could not load chain anim', src, e); }
    }
  }

  document.addEventListener('pointerdown', () => {
    game.audio.unlock();
    if (game.audio.musicOn) game.audio.setMusic(true);
  }, {once:true});

  hookUI(game);
  window.addEventListener('resize', ()=>game.resize());
})();

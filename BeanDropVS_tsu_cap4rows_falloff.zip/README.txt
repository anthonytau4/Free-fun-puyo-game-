Bean Drop VS (Tsu-inspired)
================================

Run:
- Double click `index.html` (no server needed).

Controls:
- Left/Right: move
- Z / X: rotate
- Down: soft drop
- Up or Space: hard drop (instant lock)
- P: pause
- R: restart

What's implemented:
- Classic Tsu-like chain + scoring + garbage math
- Offsetting (your chains first cancel your incoming garbage, then send the remainder)
- Garbage queue, per-drop cap, and row-based drops
- Optional All Clear (ZenKeshi) bonus and Margin Time
- Tuned timings from documented frame data (32f grace / 16f bounce / 8f rotation)
- Smart CPU: placement search + lookahead + defensive digging when under garbage

Assets:
- Uses your provided sprites + music + chain SFX in /assets
- Garbage puyo is rendered procedurally (gray with an X) if no sprite exists.

Notes:
- This is a faithful *rules-inspired* implementation, not a ROM-accurate emulator.
- If you want exact per-version frame rules, we can tune the constants in `CONFIG` inside `game.js`.
